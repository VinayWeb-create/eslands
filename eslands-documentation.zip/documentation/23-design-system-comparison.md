# 23 — Design System Comparison

Reference: Phase 1's `07-design-system.md` (two parallel styling systems:
live Tailwind pages vs. dead hand-written `.enterprise-*` CSS).

| Principle | Esland today | Enterprise pattern | Gap |
|---|---|---|---|
| Grid/containers | 6 | 8 | 2 |
| Typography scale | 6 | 9 | 3 |
| Color palette discipline | 5 | 9 | 4 |
| Contrast | Unverified (flag) | 9 | — |
| Glassmorphism usage | 6 | 7 | 1 |
| Cards | 6 | 8 | 2 |
| Buttons | 6 | 8 | 2 |
| Forms | 6 | 8 | 2 |
| Icons | 7 | 8 | 1 |
| Shadows | 6 | 8 | 2 |
| Border radius | 6 | 8 | 2 |
| Consistency (single system) | 3 | 9 | 6 |
| Modern appearance | 6 | 9 | 3 |

## The single biggest design-system issue

Esland's largest design-system gap **isn't any individual token**
(colors, radii, shadows are all reasonably chosen) — it's that **two
incompatible systems coexist** (Tailwind, live, vs. the dead
`.enterprise-*` CSS block, per Phase 1). Enterprise-grade sites are
defined as much by consistency as by any single aesthetic choice: one
container-width formula, one breakpoint set, one spacing rhythm, applied
everywhere. Closing this gap is largely a **decision + cleanup** task
(Phase 1's `16-recommendations.md`, item 6), not new visual design work.

## Color & typography vs. reference patterns

- **Enterprise IT (Accenture/IBM/Cisco-tier)**: typically restrained
  palettes — one or two brand colors plus neutral grays, high
  contrast, minimal gradient use. Esland's sky/purple/cyan glow palette
  (Phase 1 `07-design-system.md`) reads closer to consumer SaaS than
  enterprise-IT-services.
- **Modern SaaS (Stripe/Linear/Vercel-tier)**: similarly restrained but
  paired with confident large type and generous whitespace — Esland's
  spacing scale is already generous (custom `128`–`192` spacing extension
  exists), so the type/color discipline is the gap, not spacing.
- **Digital agencies (Clay/Ramotion-tier)**: more license for bold
  gradients/glow, closer to Esland's current direction — if Esland wants
  to keep the current glow aesthetic rather than shift toward IBM/Cisco
  restraint, this is the closer reference family to study.

## Dark vs. light inconsistency (Phase 1 finding, restated for design context)

Enterprise sites do sometimes mix a dark marketing homepage with a
lighter interior-page/app aesthetic (this is common — e.g. dark landing,
light app/dashboard) — so Esland's dark-homepage/light-careers split
*could* be intentional. What undermines it today is that the split looks
**unplanned** (different container widths, different card styles,
different type treatment) rather than a deliberate "marketing dark /
operational light" system.

## Recommendation priority

High: resolve the two-system conflict (pick Tailwind-only or migrate to
the legacy visual direction, per Phase 1). Medium: tighten color palette
discipline and verify contrast ratios. Low: micro-adjustments to
radius/shadow values once the system is unified.
