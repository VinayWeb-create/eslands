# 27 — UI Scorecard (Consolidated)

Scores are 1–10, qualitative judgments per the method note in
`17-enterprise-benchmark.md` — directional prioritization aids, not
measured analytics.

| Category | Current | Enterprise Standard | Gap |
|---|---|---|---|
| Brand positioning (avg of 8 sub-scores) | 5 | 10 | 5 |
| Navigation | 7 | 9 | 2 |
| Hero | 5 | 9 | 4 |
| Visual hierarchy | 6 | 9 | 3 |
| Typography | 6 | 9 | 3 |
| Color palette discipline | 5 | 9 | 4 |
| Design-system consistency | 3 | 9 | 6 |
| Motion — capability | 6 | 8 | 2 |
| Motion — restraint/consistency | 5 | 9 | 4 |
| Motion — accessibility (reduced motion) | 1 | 9 | 8 |
| Homepage storytelling | 5 | 9 | 4 |
| Services page | 5 | 9 | 4 |
| Products page | 3 | 8 | 5 |
| About page | 5 | 8 | 3 |
| Contact page | 5 | 8 | 3 |
| Footer | 6 | 8 | 2 |
| Testimonials/social proof | 7 | 8 | 1 |
| Case studies / outcomes proof | 1 | 9 | 8 |
| Technology/process transparency | 2 | 8 | 6 |
| Trust badges/certifications | 1 | 8 | 7 |
| SEO technical hygiene (Phase 1 finding: broken sitemap refs) | 4 | 9 | 5 |
| Performance (Phase 1 structural risk factors) | 5 | 8 | 3 |
| Accessibility (excl. motion, covered above) | 5 | 9 | 4 |
| Code quality / maintainability (Phase 1) | 6 | 8 | 2 |
| Conversion path clarity | 5 | 9 | 4 |

## Highest-gap items (score ≥ 5)

1. **Reduced-motion accessibility** — gap 8
2. **Case studies / outcomes proof** — gap 8
3. **Trust badges/certifications** — gap 7
4. **Technology/process transparency** — gap 6 *(cheapest fix — components already exist per Phase 1)*
5. **Design-system consistency** — gap 6 *(cheapest fix — cleanup, not new design)*
6. **SEO technical hygiene** — gap 5 *(cheapest fix — remove broken sitemap references, per Phase 1)*
7. **Products page** — gap 5
8. **Brand positioning** — gap 5

## Reading this table alongside effort

Several of the highest-gap items are also the **lowest-effort** to close
(items marked above), because Phase 1 found the underlying components
or content already exist but are disconnected, broken, or duplicated
rather than needing to be designed from zero. `28-priority-roadmap.md`
sequences work by this effort-vs-impact lens, not just raw gap size.
