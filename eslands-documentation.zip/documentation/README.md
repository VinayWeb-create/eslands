# Esland IT Solutions — Codebase Documentation

This documentation set was produced by reverse-engineering the repository
[`VinayWeb-create/eslands`](https://github.com/VinayWeb-create/eslands) as if
joining the project with no prior context. **No code was modified.** This is
analysis only, per Phase 1 rules.

## Important correction to the brief

The original discovery prompt assumes a **Next.js `app/` router** project
(with `layouts/`, `providers/`, dynamic routes, loading/error boundaries,
etc.). The actual repository is **not Next.js**. It is:

- A **Vite + React 18 single-page application** (`client/`) using
  `react-router-dom` for client-side routing (no server rendering, no
  `app/` directory, no file-based routing).
- A separate **Express + MongoDB REST API** (`server/`) that only serves
  three form-submission endpoints (contact, careers, newsletter).

All 16 phases below have been adapted to this real architecture rather than
forced into a Next.js template, so some Next.js-specific concepts (nested
layouts, loading.tsx, middleware-based route protection) don't apply and are
noted as **N/A** where relevant.

## Files in this set

| File | Contents |
|---|---|
| `01-project-overview.md` | What the project is, tech stack, high-level architecture |
| `02-folder-structure.md` | Folder-by-folder breakdown, client + server |
| `03-routing.md` | Every route, how routing works, transitions |
| `04-components.md` | Inventory of every component, props, usage, dead code |
| `05-pages.md` | Per-page breakdown (purpose, sections, SEO, forms) |
| `06-homepage.md` | Section-by-section homepage teardown |
| `07-design-system.md` | Colors, type scale, spacing, Tailwind vs. custom CSS |
| `08-assets.md` | Images, icons, fonts, logos inventory |
| `09-animations.md` | Framer Motion, CSS keyframes, scroll/hover/page-transition catalogue |
| `10-libraries.md` | Every dependency, purpose, version, upgrade notes |
| `11-seo.md` | Metadata, schema.org, sitemap, robots, per-page SEO |
| `12-performance.md` | Bundle, images, code-splitting, Web Vitals risks |
| `13-accessibility.md` | ARIA, keyboard, contrast, semantic HTML findings |
| `14-responsive.md` | Breakpoint strategy and behavior across devices |
| `15-code-quality.md` | Architecture health, duplication, dead code, technical debt |
| `16-recommendations.md` | Prioritized next steps (for Phase 2 planning) |
| `PROJECT_ANALYSIS_REPORT.md` | Executive summary tying everything together |

## How to read this

Start with `PROJECT_ANALYSIS_REPORT.md` for the 10-minute version, then drill
into the numbered files for detail on any specific area.
