# 21 — About Page Gap Analysis

Reference: Phase 1's `05-pages.md` (`/about`, 577 lines — stats, timeline
2013→present, values sections).

| Element | Current | Enterprise standard | Gap |
|---|---|---|---|
| Company story | 6 | 8 | 2 |
| Mission/vision | 5 | 8 | 3 |
| Leadership | 1 | 8 | 7 |
| Timeline | 7 | 8 | 1 |
| Achievements/stats | 6 | 8 | 2 |
| Office/locations | 3 | 8 | 5 |
| Culture | 5 | 8 | 3 |
| Brand personality | 5 | 8 | 3 |
| Trust/credibility | 4 | 9 | 5 |

## Strongest existing asset

The **timeline (2013 founding → 2018 expansion → ...)** is genuinely
close to enterprise quality already — a real founding date and growth
narrative is exactly the kind of substance enterprise buyers look for
before trusting a vendor. This should be preserved and, if anything,
extended with more recent milestones.

## Biggest gaps

- **No leadership team shown.** Enterprise buyers (and enterprise-style
  competitors) almost universally show founder/leadership photos and
  short bios — this builds accountability and trust that anonymous "50+
  team members" stat text can't replicate on its own.
- **No office/location proof.** The Organization JSON-LD (Phase 1
  `11-seo.md`) has a real London (Barking) address, but the About page
  itself doesn't visibly showcase office photos or "where we work" —
  enterprise clients often care whether a vendor has a real physical
  presence in their region.
- **Stats (15+ years, 500+ projects, 50+ team, 98% satisfaction)** are
  presented as bare numbers with no link to evidence (case studies,
  reviews, certifications) — enterprise sites usually make at least one
  of these clickable/verifiable.
- **No certifications/awards/partner-badge section** (ISO, Microsoft
  Partner, AWS Partner, industry awards, etc.) — this is one of the
  fastest, lowest-effort trust upgrades available if Esland holds any
  such credentials.

## Recommendation priority

Medium-high: add a leadership section and a certifications/partner-badge
row — both are content additions, not redesigns, and directly close the
largest gaps (leadership: 7, trust: 5) at relatively low design effort.
