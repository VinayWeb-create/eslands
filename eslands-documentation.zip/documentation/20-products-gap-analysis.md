# 20 — Products Page Gap Analysis

Reference: Phase 1's `05-pages.md` (`/products`, 286 lines, 25 items all
titled "Various Versions" with category + star rating).

## Why this reads as placeholder content

- Every one of the 25 cards shares the identical title **"Various
  Versions"** — no product has a real name.
- No product has a distinguishing description; only a category tag
  (Electronics, Computers, Networking, Software) and a generic 4-star
  rating repeated across nearly all items.
- Star ratings with no review count or source read as decorative rather
  than trust-building — enterprise/e-commerce-adjacent sites always
  attach a count ("4.8 (126 reviews)") or omit ratings entirely rather
  than show an unsupported number.
- The layout (search + category filter) is functionally reasonable —
  the gap is entirely content, not structure.

## Layout/UX evaluation

| Aspect | Current | Enterprise standard | Gap |
|---|---|---|---|
| Card layout | 6 | 8 | 2 |
| Filtering/search | 6 | 8 | 2 |
| Product hierarchy | 2 | 8 | 6 |
| Business messaging | 2 | 9 | 7 |
| CTA | 4 | 8 | 4 |
| Visual presentation | 5 | 8 | 3 |

## What a modern enterprise "solutions showcase" looks like instead

Enterprise IT companies rarely present a flat product grid at all; they
tend to organize this content one of two ways, either of which would fit
Esland better than a generic "products" grid:

1. **Solutions-by-industry or by-outcome** grid (e.g. "Retail Inventory
   Platform", "Patient Scheduling System") — each tile links to a short
   case-style page with the problem solved, tech used, and result.
2. **Named product/platform tiles** if Esland genuinely has packaged
   offerings (e.g. a proprietary CMS, a monitoring dashboard) — each with
   a real name, a 2–3 sentence description, and a screenshot or diagram
   instead of a stock photo.

## Recommendation priority

**High** — this is the single most "unfinished-looking" page on the site
and the easiest to make embarrassing if a prospective enterprise client
clicks through. Recommend either populating with real content before any
visual redesign, or folding this page's purpose into the Services/
Industries structure rather than keeping a separate generic "Products"
grid (see `25-feature-gap-analysis.md` for the "Industry Solutions"
pattern this could become).
