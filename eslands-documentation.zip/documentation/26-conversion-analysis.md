# 26 — Conversion Analysis

## Current conversion path

Visitor → Home (or a deep link) → one of several CTAs ("Get More",
"Call us", "Learn more", pricing-plan buttons, homepage contact form,
`/contact` page form, newsletter signup) → form submit → Express API →
email via nodemailer (per Phase 1's server-code review).

## Friction points identified

1. **CTA proliferation with inconsistent wording.** The homepage alone
   uses several different CTA phrasings across its 10 sections (Phase 1
   `06-homepage.md`) rather than one repeated, specific action —
   inconsistent CTA language measurably reduces click-through in
   conversion-rate research because each new phrase asks the visitor to
   re-parse what happens next.
2. **Two competing contact paths** (inline homepage form + dedicated
   `/contact` page) split intent and analytics, and risk the two forms
   drifting out of sync (already true today per Phase 1 — same validation
   logic maintained twice).
3. **No mid-funnel offer.** Every current CTA asks for the same
   high-commitment action (contact us / call). Enterprise sites typically
   layer a lower-commitment option (download a whitepaper, book a
   15-minute call, try a calculator) for visitors not ready to talk to
   sales yet — none of that exists today (see `25-feature-gap-analysis.md`).
4. **Careers "Apply Now" is a dead end** (Phase 1 finding) — for a site
   also trying to recruit talent, a non-functional CTA on the one page
   built specifically to convert candidates is a direct, fixable leak.
5. **Pricing table mismatch** (`18-homepage-gap-analysis.md`) — a
   shared-hosting-style pricing table on an enterprise-positioned
   homepage sends mixed signals about what's actually being sold,
   which can suppress rather than aid conversion for the intended
   enterprise/SMB IT-services buyer.
6. **No urgency/scarcity or social-proof-at-decision-point.** Testimonials
   exist but sit in their own section rather than appearing near CTAs
   where they'd reduce last-moment hesitation.

## What's working

- Real validation and toast feedback on the contact form reduce a common
  conversion killer (silent failures/unclear errors).
- Genuine, specific, named-client testimonials are strong raw material —
  the gap is placement and repetition, not content quality.
- The site correctly captures name/email/phone/subject/message — a
  complete-enough lead-qualification form for an SMB/mid-market IT
  services business (no missing critical fields identified).

## Recommendation priority

High: unify CTA wording into one repeated, specific action; fix the
Careers CTA; resolve the pricing-table mismatch. Medium: add one
lower-commitment mid-funnel offer (e.g. a booked call) and surface a
testimonial near each major CTA. Lower priority: full marketing-funnel
tooling (calculators, gated whitepapers) — valuable but a larger scope
item for a later phase.
