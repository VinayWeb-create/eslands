# 17 — Enterprise UI/UX Benchmark

## Method & honesty note

This benchmark is a **qualitative design-principle comparison**, not a
pixel-for-pixel audit of any named competitor's current site (some of
which redesign frequently). Scores are directional judgments meant to
guide prioritization, not measured analytics. Reference companies
(Accenture, Capgemini, Cognizant, TCS, Infosys, IBM, Microsoft, Cisco /
Stripe, Vercel, Linear, Framer, Webflow, Cloudflare, Notion / Clay,
Ramotion, Instrument, Fantasy) are used only as **pattern libraries** —
no layout, copy, or asset is to be copied from any of them.

## 1. Brand Positioning

| Category | Esland today | Enterprise standard | Gap |
|---|---|---|---|
| Professionalism | 6 | 10 | 4 |
| Trust signals | 4 | 10 | 6 |
| Innovation perception | 5 | 10 | 5 |
| Modern visual language | 6 | 10 | 4 |
| Business credibility | 5 | 10 | 5 |
| Enterprise readiness | 4 | 10 | 6 |
| Brand consistency | 5 | 10 | 5 |
| Messaging clarity | 5 | 10 | 5 |

**What enterprise leaders (Accenture/IBM/Cisco-tier) do that Esland
doesn't yet:**
- Lead with **outcomes and industries**, not service categories ("We help
  banks cut fraud losses 30%" vs. "Web Development / Networking / SEO").
- Back every claim with a **named client logo, case study link, or
  certification badge** rather than an unattributed stat.
- Keep messaging singular and repeated across every page (one value
  proposition, reworded per audience) — Esland's current copy varies
  quite a bit page to page (see `06-homepage.md`/`19-services-gap-analysis.md`
  from Phase 1/2) and the "2D animation" / "Professional Naming" service
  entries read as small-agency, not enterprise.

**What modern SaaS leaders (Stripe/Linear/Vercel-tier) do that Esland
doesn't yet:**
- Extreme message discipline: one sentence, one sub-sentence, one CTA,
  then immediate proof (logos/metrics) — no scrolling required to
  understand what the company does.
- Design restraint: fewer simultaneous effects (glow + gradient + tilt +
  carousel all at once, as Esland's homepage currently does per Phase 1's
  `09-animations.md`, reads as busier than the calmer, high-confidence
  aesthetic these companies use).

**Brand consistency issue carried over from Phase 1**: the site currently
runs a dark "glow" aesthetic on most pages and a plain white aesthetic on
`/careers` and parts of `/about`/`/contact` — enterprise sites keep one
consistent visual system across the entire site.

## Where Esland already performs reasonably well

- Skip-link and semantic structure exist (many small competitors skip
  this entirely).
- A real, working animation system (Framer Motion) is already in place —
  the gap is refinement/restraint, not capability.
- Genuine testimonial content with named clients exists — this is a real
  trust asset most small IT-services sites don't bother collecting.
- Clean codebase architecture (per Phase 1) means the improvements below
  are achievable without a rebuild.

See `27-ui-scorecard.md` for the full consolidated scoring table and
`28-priority-roadmap.md` for what to fix first.
