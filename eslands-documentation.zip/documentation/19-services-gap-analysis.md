# 19 — Services Page Gap Analysis

Reference: Phase 1's `05-pages.md` (`/services`, 459 lines, 8 service
lines each with heading/subheading/body/features, anchor-linked from the
Navbar mega-menu).

## Current presentation vs. enterprise presentation

| Aspect | Esland today | Enterprise pattern | Gap |
|---|---|---|---|
| Structure per service | Heading + paragraph + bullet feature list | Heading + business outcome + process + tech stack + proof point + CTA | 4 |
| Visual identity per service | Color/icon only (from a shared palette) | Distinct illustration or product screenshot per service | 4 |
| Copy tone | Marketing-generic prose ("no one has given any pathetic feedback...") | Specific, outcome-led, jargon-precise | 5 |
| Business value framing | Minimal — feature lists, not outcomes | Explicit ROI/business-impact framing | 5 |
| Process visibility | None on this page | Discovery → design → build → deploy → support shown per service or once globally | 4 |
| Technology/stack transparency | Not shown | Named languages/frameworks/cloud providers per service | 4 |
| Trust reinforcement | None specific to services | Relevant case study or client logo per service | 4 |
| CTA per service | Generic "Learn more" style link | Specific next step ("Talk to a cloud architect") | 3 |

## Missing elements

- **Illustrations/diagrams** — currently text + icon only; enterprise
  services pages typically pair each offering with a simple diagram
  (architecture, workflow, or before/after) to make abstract IT services
  concrete.
- **Process section** — Phase 1 found a fully-built but unused
  `DevelopmentProcess` component; reusing/adapting it here (or on the
  homepage) would close this gap without new design work from scratch.
- **Technology showcase** — Phase 1 also found an unused `TechStack`
  component with an "orbit" visual concept; same opportunity.
- **Weak hierarchy** — all 8 services currently read as equally weighted;
  enterprise sites usually lead with 2–3 "flagship" services and treat
  the rest as a supporting grid.

## Copy quality note (carried from Phase 1 code read)

Some existing body copy has grammatical/tone issues ("no one has given
any pathetic feedback about the web Development of ours") that read as
outsourced/non-native marketing copy rather than enterprise-tier writing
— a content rewrite is as important here as any visual change.

## Recommendation priority

High: rewrite copy to be outcome-led; add a shared process + tech-stack
section (reusing existing unused components as a starting point).
Medium: per-service illustration/diagram. Low: micro-animation polish on
service cards (the underlying `ServiceCard`/`TiltCard` components are
already solid per Phase 1's `04-components.md`).
