# 18 — Homepage Gap Analysis

Reference: Phase 1's `06-homepage.md` (10 inline sections: Hero,
Partners+Stats, About, Why Esland, Services, Branding CTA, Testimonials,
Pricing, Contact+Map, Newsletter).

| Element | Current | Enterprise Standard | Gap | Notes |
|---|---|---|---|---|
| Navigation | 7 | 9 | 2 | Careers missing from primary nav (footer-only, per Phase 1 `03-routing.md`) — enterprise sites put every top-level offering in the header |
| Hero headline | 5 | 9 | 4 | "Welcome to Esland IT Solution" is a greeting, not a value proposition; enterprise heroes state an outcome ("Ship secure software faster") |
| Hero subheadline | 5 | 9 | 4 | Needs one sentence of concrete differentiation |
| Primary CTA | 6 | 9 | 3 | "Get More" is vague; enterprise CTAs are specific ("Book a consultation", "See how it works") |
| Secondary CTA | 6 | 8 | 2 | "Call us" works for an SMB audience but reads low-tech next to a "Book a demo"-style secondary CTA |
| Visual hierarchy | 6 | 9 | 3 | Rotating hero carousel competes for attention with stats + tilt image in the same view |
| Spacing/typography | 6 | 9 | 3 | Generous already (Tailwind spacing scale is extended, per Phase 1 `07-design-system.md`) but inconsistent scale between dark (live) and legacy (dead) styling passes |
| Imagery | 5 | 9 | 4 | Stock-feeling banner photography vs. enterprise sites' abstract/product-screenshot imagery |
| Animation | 6 | 8 | 2 | Technically solid (Framer Motion) but "more effects at once" rather than "fewer, more confident" motion |
| Statistics | 6 | 8 | 2 | Present twice (sections 2 and 3) — enterprise sites show a stat band once, high up |
| Client logos | 6 | 9 | 3 | Real named clients exist, but no client is a recognizable brand at scale — enterprise credibility often layers "as seen in" press logos alongside client logos |
| About section | 6 | 8 | 2 | Duplicates `/about` content in miniature — fine as a pattern, but current copy is generic |
| Services preview | 5 | 9 | 4 | 8 flat cards, mixed old/new service names (see Phase 1 `06-homepage.md` duplication finding) vs. enterprise's typically 3–4 curated "pillars" linking deeper |
| Technology showcase | 2 | 8 | 6 | **Missing entirely** on the homepage — enterprise IT sites almost always show a tech-stack/partner-certification band (AWS/Azure/GCP, etc.) |
| Testimonials | 7 | 8 | 1 | Genuinely strong content (named SMB clients, specific results) — best-performing section on the site today |
| Pricing (hosting tiers) | 3 | n/a | n/a | A "GB webspace / bandwidth" hosting-tier table doesn't match an enterprise IT-services positioning at all — see note below |
| Contact section | 6 | 8 | 2 | Duplicated with `/contact` page (Phase 1 finding) |
| Footer | 6 | 8 | 2 | Functional; missing certifications/trust badges enterprise footers include |
| Overall storytelling | 5 | 9 | 4 | Reads as a list of sections rather than a single narrative arc (problem → approach → proof → offer) |

## What's missing that enterprise homepages typically include

- A **technology/partner logo band** (cloud providers, frameworks,
  certifications) distinct from the client-logo marquee.
- A **process/methodology snapshot** (discovery → build → launch →
  support) — Esland has this content buried in an unused
  `DevelopmentProcess` component (Phase 1 finding) that could be revived
  here.
- A **case-study or outcomes strip** with quantified results, not just
  quote-style testimonials.
- A single, repeated **primary CTA** that appears identically at top,
  middle, and bottom of the page (currently each section has its own
  CTA wording).

## The pricing section is a strategic mismatch, not just a design gap

A 4-tier "Standard/Business/Premium/Ultimate" webspace/bandwidth pricing
table (Phase 1 `06-homepage.md`) positions Esland as a budget web-hosting
reseller, directly undercutting the "enterprise IT solutions" positioning
the rest of the site is going for. This is flagged as **high priority** in
`28-priority-roadmap.md` regardless of any visual redesign, since no
amount of restyling fixes a category mismatch.
