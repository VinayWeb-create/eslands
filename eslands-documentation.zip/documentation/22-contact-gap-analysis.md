# 22 — Contact Page Gap Analysis

Reference: Phase 1's `05-pages.md`/`11 (Form Analysis section of the
executive report)` — `/contact` has a validated form (name/email/phone/
subject/message) posting to the Express API, plus address/phone/email
and duplicated content on the homepage.

| Element | Current | Enterprise standard | Gap |
|---|---|---|---|
| Contact form | 6 | 8 | 2 |
| Contact methods (phone/email/address) | 6 | 8 | 2 |
| Map | 0 | 7 | 7 |
| CTA clarity | 5 | 8 | 3 |
| Support options | 3 | 8 | 5 |
| Sales vs. support routing | 2 | 8 | 6 |
| Consultation booking | 1 | 8 | 7 |
| Response-time expectations | 2 | 7 | 5 |

## What's missing

- **No embedded map** — the homepage's section is even labeled "Contact &
  Map" in the source comments (Phase 1 `06-homepage.md`), but no map
  component/iframe was found in the reviewed code; a real London office
  address exists (per the SEO JSON-LD) and isn't visually reinforced with
  a map anywhere.
- **Single generic form for every inquiry type** — enterprise sites
  usually separate "Sales/New project," "Support," and "Careers/General"
  into distinct short forms or at minimum a dropdown that routes the
  message, since a CTO evaluating a £100k platform rebuild and a
  homeowner asking about hosting shouldn't hit the identical form.
- **No self-service scheduling** — a "Book a 30-minute call" calendar
  link (Calendly-style) is now a near-default enterprise pattern and
  would reduce back-and-forth email compared to "wait for a reply."
- **No stated response-time SLA** ("We reply within 1 business day") —
  a one-line trust signal enterprise sites include near the form.

## What's already solid

Real validation (client + server, per Phase 1), toast feedback, and a
schema-consistent data model are genuinely good engineering foundations
— the gaps here are almost entirely **content/feature additions**, not
a rebuild of the existing form logic.

## Recommendation priority

Medium: add a map embed and response-time line (low effort, real trust
gain). Lower priority: booking-calendar integration and inquiry-type
routing, which are valuable but larger scope items better suited to
Phase 3 planning.
