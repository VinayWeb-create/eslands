# 24 — Motion Design Comparison

Reference: Phase 1's `09-animations.md` (Framer Motion throughout: page
transitions, scroll-reveals, staggered grids, mouse-tracked tilt,
count-up, manual carousels; no GSAP; no reduced-motion support).

| Category | Current | Enterprise standard | Gap |
|---|---|---|---|
| Page transitions | 7 | 8 | 1 |
| Hover animations | 6 | 8 | 2 |
| Scroll reveals | 6 | 8 | 2 |
| Parallax | 3 | 7 | 4 |
| Button interactions | 6 | 8 | 2 |
| Card interactions (tilt) | 7 | 7 | 0 |
| Counters | 7 | 7 | 0 |
| Carousels | 5 | 8 | 3 |
| Hero animation | 6 | 8 | 2 |
| Loading animation | 3 | 7 | 4 |
| Micro-interactions | 5 | 8 | 3 |
| Cursor interactions | 2 | 7 | 5 |
| 3D motion | 0 | 6 | 6 |
| Animation consistency | 5 | 9 | 4 |
| Performance/restraint | 5 | 9 | 4 |
| Accessibility (reduced motion) | 1 | 9 | 8 |

## Where Esland's motion already matches enterprise/SaaS quality

- **Card tilt effect** (`TiltCard`) is a genuinely well-built,
  touch-aware micro-interaction on par with what a Stripe/Linear-tier
  site would ship — this doesn't need rework, just consistent
  application.
- **Count-up stats** are a standard, correctly-implemented enterprise
  pattern already in place.
- **Page transition wrapper** (fade/slide on route change) matches common
  practice.

## Where the gap is real

- **No reduced-motion support anywhere** (Phase 1 finding) — this is the
  single largest, and easiest, gap to close: every enterprise-grade site
  respects `prefers-reduced-motion`, both as an accessibility requirement
  and increasingly as a baseline expectation from enterprise procurement/
  accessibility audits.
- **Animation "loudness"**: the homepage currently layers hero carousel +
  glow blur + gradient background + tilt cards + staggered reveals all in
  view together. Enterprise/SaaS references tend toward **one motion idea
  per section** — Stripe/Linear typically use a single signature
  animation (a subtle gradient shift or one hero animation) rather than
  many simultaneous effects, which reads as more confident and higher-end
  than "more animation."
- **No loading-state animation** for async content (e.g. `/careers`'s job
  fetch uses a plain skeleton pulse — reasonable, but there's no
  consistent loading pattern applied elsewhere, e.g. for the contact
  form's submit state beyond a toast).
- **No cursor-based interaction** beyond the tilt effect — some
  agency-tier references (Instrument/Fantasy) use custom cursor states as
  a signature touch; optional polish, not a gap that matters for an
  enterprise-IT audience specifically.
- **3D**: `three.js`/`@react-three/fiber`/`@react-three/drei` are
  installed but unused (Phase 1 finding) — if 3D is genuinely wanted
  (e.g. an interactive network/globe visual, common on cloud/infra
  sites), the dependency is already there; if not, it should be removed
  rather than left as unused weight.

## Recommendation priority

**Highest priority of any Phase 2 item**: add `prefers-reduced-motion`
support — small effort, meaningful accessibility and enterprise-procurement
compliance win. Medium: reduce simultaneous effects per section for a
calmer, higher-confidence feel. Low: cursor interactions, 3D visuals.
