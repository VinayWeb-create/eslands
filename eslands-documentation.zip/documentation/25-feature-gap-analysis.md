# 25 — Enterprise Feature Gap Analysis

Each feature below is scored **Present / Partial / Missing** against the
current site (per Phase 1's page/route inventory) with a note on why
enterprise buyers expect it.

| Feature | Status | Why it matters |
|---|---|---|
| Case Studies | Missing | Enterprise buyers want quantified proof (problem→approach→result) before a sales call; testimonials alone (present) are weaker evidence than a structured case study |
| Industry Solutions | Partial | An `Industries.jsx` page exists in the codebase but isn't routed or linked (Phase 1 finding) — this is the fastest feature win available, since the content may already largely exist |
| Technology Stack | Partial | An unused `TechStack` component exists (Phase 1) — reviving/adapting it closes this gap with far less effort than building from scratch |
| Development Process | Partial | An unused `DevelopmentProcess` component exists (Phase 1) — same opportunity as above |
| Client Success Stories | Partial | Real named-client testimonials exist (strong content) but aren't framed as "success stories" with outcomes/metrics |
| Awards / Certifications | Missing | No badges (ISO, cloud-partner tiers, industry awards) found anywhere in the codebase |
| Global Presence | Missing | Only one London address in the Organization schema; if Esland serves clients beyond the UK, this isn't communicated anywhere |
| Resource Centre / Blog | Missing | No blog/insights section — a common enterprise-IT SEO and thought-leadership channel |
| FAQ | Missing | No FAQ page or section found on any reviewed page |
| Knowledge Base | Missing | Not applicable unless Esland has a support product; low priority unless there's a support offering |
| ROI Calculator | Missing | A common enterprise conversion tool (e.g. "estimate your cloud migration savings") — meaningful lead-gen device if relevant to Esland's services |
| Project Estimator | Missing | Similar to above; pairs well with the Contact page's missing consultation-booking gap (`22-contact-gap-analysis.md`) |
| Interactive Consultation / Booking | Missing | No calendar/booking integration found |
| AI Assistant | Missing | Not present; increasingly common on enterprise-IT sites as a first-line FAQ/lead-qualification tool, but should be scoped as a Phase 3+ feature, not urgent |
| Support Portal | Missing | Not applicable unless Esland runs managed services with SLAs; flag for business decision, not purely design |
| Career Benefits | Partial | `/careers` lists open roles but no benefits/culture content beyond department filters |
| Downloads / Whitepapers | Missing | No gated or ungated content assets found |

## Highest-leverage feature additions given the existing codebase

Because Phase 1 found that `Industries`, `TechStack`, and
`DevelopmentProcess` already exist as built (if disconnected) components/
pages, **these three are the cheapest wins on this entire list** — the
content and component work is largely already done; what's missing is
routing, navigation, and integration into the page flow, not net-new
design or engineering.

## What genuinely requires new content/business input (not just design)

Case studies, awards/certifications, global presence claims, and any
ROI/estimator tool require real business facts (actual project outcomes,
actual certifications held, actual office locations) that can't be
fabricated — these should be scoped with the Esland team directly rather
than assumed during design work.

## Recommendation priority

High: reconnect `Industries`/`TechStack`/`DevelopmentProcess`. Medium:
build a real Case Studies section once source material (client outcomes)
is available. Lower priority / business-dependent: awards, global
presence, ROI calculator, AI assistant, support portal.
